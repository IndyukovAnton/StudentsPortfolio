import pygame

pygame.init()

DECRYPTED_120 = pygame.font.Font('fonts/Decrypted.ttf', 120)

OLD_SOVIET_26 = pygame.font.Font('fonts/Old-Soviet.otf', 26)

NORD_STAR_DECO_96 = pygame.font.Font('fonts/Nord-Star-Deco.ttf', 96)