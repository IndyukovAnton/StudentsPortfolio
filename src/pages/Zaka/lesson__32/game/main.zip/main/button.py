import pygame
import settings
import font

class MenuButton:

    def __init__(self, font, text, color_text, background_color, pos_x, pos_y, size):
        self.button = pygame.Surface(size)
        self.button.fill(background_color)
        self.text = font.render(text, 1, color_text)
        self.rect = self.button.get_rect(center=(pos_x, pos_y))
        self.text_rect = self.text.get_rect(center=(pos_x, pos_y - 15))

    def draw(self, screen):
        screen.blit(self.button, self.rect)
        screen.blit(self.text, self.text_rect)

play_ = MenuButton( 
                    font=font.DECRYPTED_120, text="PLAY", 
                    color_text=(0, 0, 0,),
                    background_color=(255, 255, 255), 
                    pos_x=settings.SCREEN_WIDTH // 2, 
                    pos_y=settings.SCREEN_HEIGHT // 4,
                    size=(400, 75)
                    )
easy = MenuButton( 
                    font=font.DECRYPTED_120, text="EASY", 
                    color_text=(0, 0, 0,),
                    background_color=(255, 255, 255), 
                    pos_x=settings.SCREEN_WIDTH // 2, 
                    pos_y=settings.SCREEN_HEIGHT // 4,
                    size=(400, 75)
                    )
overage = MenuButton( 
                    font=font.DECRYPTED_120, text="OVERAGE", 
                    color_text=(0, 0, 0,),
                    background_color=(255, 255, 255), 
                    pos_x=settings.SCREEN_WIDTH // 2, 
                    pos_y=settings.SCREEN_HEIGHT // 4 + settings.H // 4,
                    size=(400, 75)
                    )
hard = MenuButton( 
                    font=font.DECRYPTED_120, text="HARD", 
                    color_text=(0, 0, 0,),
                    background_color=(255, 255, 255), 
                    pos_x=settings.SCREEN_WIDTH // 2, 
                    pos_y=settings.SCREEN_HEIGHT // 4 * 3,
                    size=(400, 75)
                    )
exit = MenuButton( 
                    font=font.DECRYPTED_120, text="EXIT", 
                    color_text=(0, 0, 0),
                    background_color=(255, 255, 255), 
                    pos_x=settings.SCREEN_WIDTH // 2, 
                    pos_y=settings.SCREEN_HEIGHT // 4 * 3,
                    size=(400, 75)
                    )
settings_button = MenuButton(
                        font=font.DECRYPTED_120, text="SETTINGS",
                        color_text=(0, 0, 0),
                        background_color=(255, 255, 255),
                        pos_x=settings.SCREEN_WIDTH // 2,
                        pos_y=settings.SCREEN_HEIGHT // 4 * 2,
                        size=(400, 75))
exit_to_main_menu = MenuButton( 
                    font=font.DECRYPTED_120, text="EXIT TO MAIN MENU", 
                    color_text=(0, 0, 0),
                    background_color=(255, 255, 255), 
                    pos_x=settings.SCREEN_WIDTH // 2, 
                    pos_y=settings.SCREEN_HEIGHT // 3 * 2,
                    size=(675, 75)
                    )