import pygame
import font
import color
import player
import home
import settings

def rotate_image(image_position, image, object):
    if image_position == object.left_position:
        return pygame.transform.rotate(image, 180)
    if image_position == object.right_position:
        return pygame.transform.rotate(image, 0)
    if image_position == object.up_position:
        return pygame.transform.rotate(image, 90)
    if image_position == object.down_position:
        return pygame.transform.rotate(image, -90)

def draw_game_over(screen):
    gameOver = font.NORD_STAR_DECO_96.render('Game Over', 1, color.WHITE)
    gameOverRect = gameOver.get_rect(center=(900 // 2, 650 // 2))
    settings.screen.blit(gameOver, gameOverRect)