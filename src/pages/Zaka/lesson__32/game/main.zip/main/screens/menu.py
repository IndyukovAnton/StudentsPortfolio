import pygame
import font
import settings

class MenuButton:

    def __init__(self, font, text, color_text, background_color, pos_x, pos_y, size):
        self.button = pygame.Surface(size)
        self.button.fill(background_color)
        self.text = font.render(text, 1, color_text)
        self.rect = self.button.get_rect(center=(pos_x, pos_y))
        self.text_rect = self.text.get_rect(center=(pos_x, pos_y - 15))

    def draw(self, screen):
        screen.blit(self.button, self.rect)
        screen.blit(self.text, self.text_rect)


play_button = MenuButton( 
                    font=font.DECRYPTED_120, text="PLAY", 
                    color_text=(0, 0, 0,),
                    background_color=(255, 255, 255), 
                    pos_x=settings.SCREEN_WIDTH // 2, 
                    pos_y=settings.SCREEN_HEIGHT // 5,
                    size=(400, 75)
                    )

exit_button = MenuButton( 
                    font=font.DECRYPTED_120, text="EXIT", 
                    color_text=(0, 0, 0),
                    background_color=(255, 255, 255), 
                    pos_x=settings.SCREEN_WIDTH // 2, 
                    pos_y=settings.SCREEN_HEIGHT // 5 * 4,
                    size=(400, 75)
                    )

settings_button = MenuButton(
                        font=font.DECRYPTED_120, text="SETTINGS",
                        color_text=(0, 0, 0),
                        background_color=(255, 255, 255),
                        pos_x=settings.SCREEN_WIDTH // 2,
                        pos_y=settings.SCREEN_HEIGHT // 5 * 2.5,
                        size=(400, 75)
                    )

def main_menu(game_manager):

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                if play_button.rect.collidepoint(pygame.mouse.get_pos()):
                    game_manager.state = "choose_complexity"
                elif settings_button.rect.collidepoint(pygame.mouse.get_pos()):
                    game_manager.state = "settings_screen"
                elif exit_button.rect.collidepoint(pygame.mouse.get_pos()):
                    pygame.quit()

    settings.screen.fill((0, 0, 197))
    play_button.draw(settings.screen)
    settings_button.draw(settings.screen)
    exit_button.draw(settings.screen)
    pygame.display.update()