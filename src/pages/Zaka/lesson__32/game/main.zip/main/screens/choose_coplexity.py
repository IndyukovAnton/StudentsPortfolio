import pygame
import screens.menu
import settings

DECRYPTED_120 = pygame.font.Font('fonts/Decrypted.ttf', 120)

easy_button = screens.menu.MenuButton( 
                    font=DECRYPTED_120, text="EASY", 
                    color_text=(0, 0, 0,),
                    background_color=(255, 255, 255), 
                    pos_x=settings.SCREEN_WIDTH // 2, 
                    pos_y=settings.SCREEN_HEIGHT // 4,
                    size=(400, 75)
                    )
overage_button = screens.menu.MenuButton( 
                    font=DECRYPTED_120, text="OVERAGE", 
                    color_text=(0, 0, 0,),
                    background_color=(255, 255, 255), 
                    pos_x=settings.SCREEN_WIDTH // 2, 
                    pos_y=settings.SCREEN_HEIGHT // 4 * 2,
                    size=(400, 75)
                    )
hard_button = screens.menu.MenuButton( 
                    font=DECRYPTED_120, text="HARD", 
                    color_text=(0, 0, 0,),
                    background_color=(255, 255, 255), 
                    pos_x=settings.SCREEN_WIDTH // 2, 
                    pos_y=settings.SCREEN_HEIGHT // 4 * 3,
                    size=(400, 75)
                    )

def choose_complexity(game_manager):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if easy_button.rect.collidepoint(pygame.mouse.get_pos()):
                        settings.zombie_spawn_rate = 5
                        settings.medkit_spawn_rate = 30
                        settings.ammo_spawn_rate = 25
                        game_manager.state = "game"
                    elif overage_button.rect.collidepoint(pygame.mouse.get_pos()):
                        settings.zombie_spawn_rate = 3
                        settings.medkit_spawn_rate = 45
                        settings.ammo_spawn_rate = 40
                        game_manager.state = "game"
                    elif hard_button.rect.collidepoint(pygame.mouse.get_pos()):
                        settings.zombie_spawn_rate = 1
                        settings.medkit_spawn_rate = 60
                        settings.ammo_spawn_rate = 50
                        game_manager.state = "game"

        settings.screen.fill((0, 200, 0))
        easy_button.draw(settings.screen)
        overage_button.draw(settings.screen)
        hard_button.draw(settings.screen)
        pygame.display.update()