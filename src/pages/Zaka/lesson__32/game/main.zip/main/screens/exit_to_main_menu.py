import pygame
import settings
import player
import home
import font
from screens.menu import MenuButton, settings_button

exit_to_main_menu_button = MenuButton( 
                    font=font.DECRYPTED_120, text="EXIT TO MAIN MENU", 
                    color_text=(0, 0, 0),
                    background_color=(255, 255, 255), 
                    pos_x=settings.SCREEN_WIDTH // 2, 
                    pos_y=settings.SCREEN_HEIGHT // 3 * 2,
                    size=(675, 75)
                    )

def exit_to_main_menu(state):
    global timePassedAfterSpawnZombie
    global timePassedAfterSpawnMedkit
    global timePassedAfterSpawnAmmoBox

    settings_button.rect.center = (settings.SCREEN_WIDTH // 2, settings.SCREEN_HEIGHT // 3)
    settings_button.text_rect = settings_button.text.get_rect(center=(settings.SCREEN_WIDTH // 2, settings.SCREEN_HEIGHT // 3 - 15))
    timePassedAfterSpawnZombie = 0
    timePassedAfterSpawnMedkit = 0
    timePassedAfterSpawnAmmoBox = 0
    player.surv.number_of_bullets = 100
    home.home.health = 100


    for event in pygame.event.get():
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                if exit_to_main_menu_button.rect.collidepoint(pygame.mouse.get_pos()):
                    state = "start_screen"
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                state = "game"
        
    settings.screen.fill((210, 210, 210))
    settings_button.draw(settings.screen)
    exit_to_main_menu_button.draw(settings.screen)
    pygame.display.update()