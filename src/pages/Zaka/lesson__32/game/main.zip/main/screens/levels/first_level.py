import pygame
import random
import player
from zombie import Zombie
from medkit import Medkit
from box_ammo import BoxAmmo
from projectile import projectileImage
import function
import settings
from home import heart, home, draw_health_home
import sound
import background


zombs = pygame.sprite.Group()
medkits = pygame.sprite.Group()
boxes = pygame.sprite.Group()
projectiles = pygame.sprite.Group()

timePassedAfterSpawnZombie = 0
timePassedAfterSpawnMedkit = 0
timePassedAfterSpawnAmmoBox = 0

clockTick = 0

def game(game_manager):
        global clockTick
        global timePassedAfterSpawnZombie
        global timePassedAfterSpawnMedkit
        global timePassedAfterSpawnAmmoBox
        spacePressed = False
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            player.surv.check_move(event)
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    spacePressed = True
                elif event.key == pygame.K_ESCAPE:
                    game_manager.state = "exit_to_main_menu"
        
        if spacePressed:
            player.surv.shoot(projectiles)

        t = pygame.time.get_ticks()
        deltaTime = t - clockTick
        clockTick = t
        timePassedAfterSpawnZombie += deltaTime / 1000
        timePassedAfterSpawnMedkit += deltaTime / 1000
        timePassedAfterSpawnAmmoBox += deltaTime / 1000

        if timePassedAfterSpawnZombie > settings.zombie_spawn_rate:
            zombie = Zombie()
            zombs.add(zombie)
            #zombieSound.play()
            timePassedAfterSpawnZombie = 0
        if timePassedAfterSpawnMedkit > settings.medkit_spawn_rate:
            medkit = Medkit("images/ammo/medkit.png", random.randint(1, 2))
            medkits.add(medkit)
            timePassedAfterSpawnMedkit = 0
        if timePassedAfterSpawnAmmoBox > settings.ammo_spawn_rate:
            box = BoxAmmo("images/ammo/boxBullet.png", random.randint(1, 2))
            boxes.add(box)
            timePassedAfterSpawnAmmoBox = 0

        for medkit in medkits:
            medkit.surv_colliderect_with_medkit(sound.catchSound, medkits)
        for box in boxes:
            box.surv_colliderect_with_box(sound.catchSound, boxes)

        if home.health > 0:
            settings.screen.blit(background.sand, (0, 0))
            home.draw(settings.screen)
            player.surv.update()
            player.surv.draw(settings.screen)
            draw_health_home(settings.screen, heart)
            player.draw_bullet(settings.screen, projectileImage)
            zombs.update(home, zombs, player.surv)
            zombs.draw(settings.screen)
            projectiles.update(medkits=medkits, zombies=zombs, boxes=boxes, projectile_group=projectiles)
            projectiles.draw(settings.screen)
            medkits.draw(settings.screen)
            boxes.draw(settings.screen)
        elif home.health <= 0:
            function.draw_game_over(settings.screen)

        pygame.display.update()
        