import pygame
import settings
import font
from screens.menu import MenuButton

exit = MenuButton( 
                    font=font.DECRYPTED_120, text="EXIT", 
                    color_text=(0, 0, 0),
                    background_color=(255, 255, 255), 
                    pos_x=settings.SCREEN_WIDTH // 2, 
                    pos_y=settings.SCREEN_HEIGHT // 4 * 3,
                    size=(400, 75)
                    )

def settings_screen(game_manager):
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                if exit.rect.collidepoint(pygame.mouse.get_pos()):
                    game_manager.state = "main_menu"

    settings.screen.fill((150, 0, 200))
    exit.draw(settings.screen)
    pygame.display.update()