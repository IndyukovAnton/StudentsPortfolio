import pygame

sand = pygame.image.load("images/background/sand.jpg")