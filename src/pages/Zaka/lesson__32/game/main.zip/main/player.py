import pygame
import function
from projectile import Projectile, rotate_projectile
import font
import color
import settings


class Player:
    def __init__(self, number_of_bullets, speed):
        self.images_move = []
        self.images_shoot = []
        for i in range(20):
            self.sprite_move = pygame.image.load(f'images/player/move/survivor-move_shotgun_{i}.png')
            self.sprite_move = pygame.transform.scale(self.sprite_move, (150, 100))
            self.images_move.append(self.sprite_move)
        for i in range(3):
            self.sprite_shoot = pygame.image.load(f'images/player/shoot/survivor-shoot_shotgun_{i}.png')
            self.sprite_shoot = pygame.transform.scale(self.sprite_shoot, (150, 100))
            self.images_shoot.append(self.sprite_shoot)
        self.move_index = 0
        self.shoot_index = 0
        self.image = self.images_move[self.move_index]
        self.rect = self.image.get_rect(center=(900 // 2, 600 // 2))
        self.number_of_bullets = number_of_bullets
        self.speed = speed
        self.MOVE_LEFT = False
        self.MOVE_RIGHT = False
        self.MOVE_UP = False
        self.MOVE_DOWN = False
        self.left_position = pygame.transform.rotate(self.image, 180)
        self.right_position = pygame.transform.rotate(self.image, 0)
        self.up_position = pygame.transform.rotate(self.image, 90)
        self.down_position = pygame.transform.rotate(self.image, -90)
        self.image_position = self.right_position
    
    def check_move(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                self.MOVE_LEFT = True
            if event.key == pygame.K_RIGHT:
                self.MOVE_RIGHT = True
            if event.key == pygame.K_DOWN:
                self.MOVE_DOWN = True
            if event.key == pygame.K_UP:
                self.MOVE_UP = True
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT:
                self.MOVE_LEFT = False
            if event.key == pygame.K_RIGHT:
                self.MOVE_RIGHT = False
            if event.key == pygame.K_UP:
                self.MOVE_UP = False
            if event.key == pygame.K_DOWN:
                self.MOVE_DOWN = False
    
    def animation(self):
        self.move_index += 0.5
        if int(self.move_index) >= len(self.images_move):
            self.move_index = 0
        self.image = self.images_move[int(self.move_index)]
        self.image = function.rotate_image(self.image_position, self.image, self)

    def update(self):
        if self.MOVE_LEFT:
            if self.rect.left >= 0:
                self.rect.move_ip(-self.speed, 0)
                self.image_position = self.left_position
                self.animation()
        if self.MOVE_RIGHT:
            if self.rect.right <= 900:
                self.rect.move_ip(self.speed, 0)
                self.image_position = self.right_position
                self.animation()
        if self.MOVE_UP:
            if self.rect.top >= 0:
                self.rect.move_ip(0, -self.speed)
                self.image_position = self.up_position
                self.animation()
        if self.MOVE_DOWN:
            if self.rect.bottom <= 650:
                self.rect.move_ip(0, self.speed)
                self.image_position = self.down_position
                self.animation()
    def shoot(self, projectiles_group):
        if self.number_of_bullets > 0:
            if surv.image_position == self.left_position:
                direction = 3
            elif surv.image_position == self.right_position:
                direction = 1
            elif surv.image_position == self.up_position:
                direction = 2
            elif surv.image_position == self.down_position:
                direction = 4
            projectile = Projectile('images/bullet/projectile.png', direction)
            projectile.image = rotate_projectile(projectile.image, projectile)
            self.shoot_index += 1
            if int(self.shoot_index) >= len(self.images_shoot):
                self.shoot_index = 0
            self.image = self.images_shoot[int(self.shoot_index)]
            self.image = function.rotate_image(self.image_position, self.image, self)
            self.number_of_bullets -= 1
            projectiles_group.add(projectile)
    def draw(self, screen):
        screen.blit(self.image, self.rect)

surv = Player(100, 6)

def draw_bullet(screen, image):
    settings.screen.blit(image, (870, 620))
    surv_of_billets = font.OLD_SOVIET_26.render(f'{surv.number_of_bullets}', 1, color.WHITE)
    settings.screen.blit(surv_of_billets, (835, 620))