import pygame
import home
import player

class Medkit(pygame.sprite.Sprite):
    def __init__(self, image, direction):
        pygame.sprite.Sprite.__init__(self)
        self.direction = direction
        self.hp = 100 - home.home.health
        self.image = pygame.image.load(image)
        self.rect = self.image.get_rect()
        if self.direction == 1:
            self.rect = self.image.get_rect(center=(325, 219))
        if self.direction == 2:
            self.rect = self.image.get_rect(center=(575, 431))

    def surv_colliderect_with_medkit(self, sound, group):
        if player.surv.rect.colliderect(self.rect):
            sound.play()
            home.home.health += self.hp
            group.remove(self)
