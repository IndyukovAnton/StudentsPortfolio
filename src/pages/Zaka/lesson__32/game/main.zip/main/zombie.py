import pygame
import random
import settings


def rotate_zombie(image, direction):
    if direction == 1:
        return pygame.transform.rotate(image, 0)
    elif direction == 2:
        return pygame.transform.rotate(image, 180)
    elif direction == 3:
        return pygame.transform.rotate(image, 90)
    else:
        return pygame.transform.rotate(image, -90)
    
def move_zombie_rect(rect, direction, speed):
    if direction == 1:
        rect.move_ip(speed, 0)
    elif direction == 2:
        rect.move_ip(-speed, 0)
    elif direction == 3:
        rect.move_ip(0, -speed)
    else:
        rect.move_ip(0, speed)

def get_move_zombie_sprites():
    images_move = []
    for i in range(1, 17):
        sprite_move = pygame.image.load(f'images/zombie/move/skeleton-move_{i}.png')
        sprite_move = pygame.transform.scale(sprite_move, (125, 125))
        images_move.append(sprite_move)
    return images_move

def get_attack_zombie_sprites():
    images_attack = []
    for i in range(9):
        sprite_attack = pygame.image.load(f'images/zombie/attack/skeleton-attack_{i}.png')
        sprite_attack = pygame.transform.scale(sprite_attack, (125, 125))
        images_attack.append(sprite_attack)
    return images_attack

class Zombie(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.images_move = get_move_zombie_sprites()
        self.images_attack = get_attack_zombie_sprites()
        self.move_index = 0
        self.attack_index = 0
        self.image = self.images_move[self.move_index]
        self.rect = self.image.get_rect(center=(0, settings.SCREEN_HEIGHT // 2))
        self.speed = 2
        self.direction = random.randint(1, 4)
        self.health = 100
        self.damage = 10
        self.set_position()
    
    def set_position(self):
        if self.direction == 1:
            self.rect.center = (0, settings.SCREEN_HEIGHT // 2)
        if self.direction == 2:
            self.rect.center = (settings.SCREEN_WIDTH, settings.SCREEN_HEIGHT // 2)
        if self.direction == 3:
            self.rect.center = (settings.SCREEN_WIDTH // 2, settings.SCREEN_HEIGHT)
        if self.direction == 4:
            self.rect.center = (settings.SCREEN_WIDTH // 2, 0)

    def update(self, home, group, player):
        if self.rect.colliderect(home.rect):
            self.attack_index += 0.25
            if int(self.attack_index) >= len(self.images_attack):
                self.attack_index = 0
                home.health -= self.damage
                if home.health < 0:
                    home.health = 0
                group.remove(self)
            self.image = self.images_attack[int(self.attack_index)]
            self.image = rotate_zombie(self.image, self.direction)
        else:
            self.move_index += 0.25
            if int(self.move_index) >= len(self.images_move):
                self.move_index = 0
            self.image = self.images_move[int(self.move_index)]
            self.image = rotate_zombie(self.image, self.direction)
            if not self.rect.colliderect(player.rect):
                move_zombie_rect(self.rect, self.direction, self.speed)