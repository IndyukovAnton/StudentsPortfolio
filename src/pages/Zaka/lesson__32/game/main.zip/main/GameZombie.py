import pygame
import random

pygame.init()

pygame.mixer.pre_init(frequency=44100, size=-16, channels=2, buffer=512, devicename=None)

white = (255, 255, 255)
blue = (0, 0, 255)
green = (0, 255, 0)
red = (255, 0, 0)

zombieSpawnRate = 3
medkitSpawnRate = 10
ammoSpawnRate = 10

zombs = pygame.sprite.Group()
timePassedAfterSpawnZombie = 0
medkits = pygame.sprite.Group()
timePassedAfterSpawnMedkit = 0
boxes = pygame.sprite.Group()
timePassedAfterSpawnAmmoBox = 0
projectiles = pygame.sprite.Group()

FPS = 60
clock = pygame.time.Clock()
clockTick = 0

decrypted_120 = pygame.font.Font('fonts/Decrypted.ttf', 120)

class GameState:
    def __init__(self):
        self.state = "start_screen"

    def start_screen(self):
        settings.rect.center = (W // 2, H // 4 * 2)
        settings.text_rect = settings.text.get_rect(center=(W // 2, H // 4 * 2 - 15))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if play_.rect.collidepoint(pygame.mouse.get_pos()):
                        self.state = "choose_complexity"
                    elif settings.rect.collidepoint(pygame.mouse.get_pos()):
                        self.state = "settings_screen"
                    elif exit.rect.collidepoint(pygame.mouse.get_pos()):
                        pygame.quit()

        screen.fill((0, 0, 197))
        play_.draw(screen)
        settings.draw(screen)
        exit.draw(screen)
        pygame.display.update()

    def choose_complexity(self):
        global zombieSpawnRate
        global medkitSpawnRate
        global ammoSpawnRate
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if easy.rect.collidepoint(pygame.mouse.get_pos()):
                        zombieSpawnRate = 5
                        medkitSpawnRate = 30
                        ammoSpawnRate = 25
                        self.state = "game"
                    if overage.rect.collidepoint(pygame.mouse.get_pos()):
                        zombieSpawnRate = 3
                        medkitSpawnRate = 45
                        ammoSpawnRate = 40
                        self.state = "game"
                    if hard.rect.collidepoint(pygame.mouse.get_pos()):
                        zombieSpawnRate = 1
                        medkitSpawnRate = 60
                        ammoSpawnRate = 50
                        self.state = "game"

        screen.fill((0, 200, 0))
        easy.draw(screen)
        overage.draw(screen)
        hard.draw(screen)
        pygame.display.update()

    def settings_screen(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if exit.rect.collidepoint(pygame.mouse.get_pos()):
                        self.state = "start_screen"

        screen.fill((150, 0, 200))
        exit.draw(screen)
        pygame.display.update()

    def exit_to_main_menu(self):
        global timePassedAfterSpawnZombie
        global timePassedAfterSpawnMedkit
        global timePassedAfterSpawnAmmoBox

        settings.rect.center = (W // 2, H // 3)
        settings.text_rect = settings.text.get_rect(center=(W // 2, H // 3 - 15))
        timePassedAfterSpawnZombie = 0
        timePassedAfterSpawnMedkit = 0
        timePassedAfterSpawnAmmoBox = 0
        surv.number_of_bullets = 100
        home.health = 100

        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if exit_to_main_menu.rect.collidepoint(pygame.mouse.get_pos()):
                        self.state = "start_screen"
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.state = "game"
        
        screen.fill((210, 210, 210))
        settings.draw(screen)
        exit_to_main_menu.draw(screen)
        pygame.display.update()

    def game(self):
        global zombieSpawnRate
        global medkitSpawnRate
        global ammoSpawnRate
        global clockTick
        global timePassedAfterSpawnZombie
        global timePassedAfterSpawnMedkit
        global timePassedAfterSpawnAmmoBox
        spacePressed = False
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            surv.check_move(event)
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    spacePressed = True
                elif event.key == pygame.K_ESCAPE:
                    self.state = "exit_to_main_menu"

        
        if spacePressed:
            surv.shoot()

        t = pygame.time.get_ticks()
        deltaTime = t - clockTick
        clockTick = t
        timePassedAfterSpawnZombie += deltaTime / 1000
        timePassedAfterSpawnMedkit += deltaTime / 1000
        timePassedAfterSpawnAmmoBox += deltaTime / 1000

        if timePassedAfterSpawnZombie > zombieSpawnRate:
            zombie = Zombie()
            zombs.add(zombie)
            #zombieSound.play()
            timePassedAfterSpawnZombie = 0
        if timePassedAfterSpawnMedkit > medkitSpawnRate:
            medkit = Medkit("images/medkit.png", random.randint(1, 2))
            medkits.add(medkit)
            timePassedAfterSpawnMedkit = 0
        if timePassedAfterSpawnAmmoBox > ammoSpawnRate:
            box = BoxAmmo("images/boxBullet.png", random.randint(1, 2))
            boxes.add(box)
            timePassedAfterSpawnAmmoBox = 0

        check_projectiles_colliderect(projectiles)
        for medkit in medkits:
            medkit.surv_colliderect_with_medkit(catchSound, medkits)
        for box in boxes:
            box.surv_colliderect_with_box(catchSound, boxes)

        if home.health > 0:
            screen.blit(sand, (0, 0))
            home.draw(screen)
            surv.update()
            surv.draw(screen)
            draw_health_home(screen, heart)
            draw_bullet(screen, projectileImage)
            zombs.update()
            zombs.draw(screen)
            projectiles.update()
            projectiles.draw(screen)
            medkits.draw(screen)
            boxes.draw(screen)
        elif home.health <= 0:
            draw_game_over(screen)

        pygame.display.update()

    def state_manager(self):
        if self.state == "start_screen":
            self.start_screen()
        elif self.state == "game":
            self.game()
        elif self.state == "choose_complexity":
            self.choose_complexity()
        elif self.state == "settings_screen":
            self.settings_screen()
        elif self.state == "exit_to_main_menu":
            self.exit_to_main_menu()

class MenuButton:

    def __init__(self, font, text, color_text, background_color, pos_x, pos_y, size):
        self.button = pygame.Surface(size)
        self.button.fill(background_color)
        self.text = font.render(text, 1, color_text)
        self.rect = self.button.get_rect(center=(pos_x, pos_y))
        self.text_rect = self.text.get_rect(center=(pos_x, pos_y - 15))

    def draw(self, screen):
        screen.blit(self.button, self.rect)
        screen.blit(self.text, self.text_rect)

class Player:
    def __init__(self, number_of_bullets, speed):
        self.images_move = []
        self.images_shoot = []
        for i in range(20):
            self.sprite_move = pygame.image.load(f'move/survivor-move_shotgun_{i}.png')
            self.sprite_move = pygame.transform.scale(self.sprite_move, (150, 100))
            self.images_move.append(self.sprite_move)
        for i in range(3):
            self.sprite_shoot = pygame.image.load(f'shoot/survivor-shoot_shotgun_{i}.png')
            self.sprite_shoot = pygame.transform.scale(self.sprite_shoot, (150, 100))
            self.images_shoot.append(self.sprite_shoot)
        self.move_index = 0
        self.shoot_index = 0
        self.image = self.images_move[self.move_index]
        self.rect = self.image.get_rect(center=(900 // 2, 600 // 2))
        self.number_of_bullets = number_of_bullets
        self.speed = speed
        self.MOVE_LEFT = False
        self.MOVE_RIGHT = False
        self.MOVE_UP = False
        self.MOVE_DOWN = False
        self.left_position = pygame.transform.rotate(self.image, 180)
        self.right_position = pygame.transform.rotate(self.image, 0)
        self.up_position = pygame.transform.rotate(self.image, 90)
        self.down_position = pygame.transform.rotate(self.image, -90)
        self.image_position = self.right_position
    
    def check_move(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                self.MOVE_LEFT = True
            if event.key == pygame.K_RIGHT:
                self.MOVE_RIGHT = True
            if event.key == pygame.K_DOWN:
                self.MOVE_DOWN = True
            if event.key == pygame.K_UP:
                self.MOVE_UP = True
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT:
                self.MOVE_LEFT = False
            if event.key == pygame.K_RIGHT:
                self.MOVE_RIGHT = False
            if event.key == pygame.K_UP:
                self.MOVE_UP = False
            if event.key == pygame.K_DOWN:
                self.MOVE_DOWN = False
    
    def animation(self):
        self.move_index += 0.5
        if int(self.move_index) >= len(self.images_move):
            self.move_index = 0
        self.image = self.images_move[int(self.move_index)]
        self.image = rotate_image(self.image_position, self.image, self)

    def update(self):
        if self.MOVE_LEFT:
            if self.rect.left >= 0:
                self.rect.move_ip(-self.speed, 0)
                self.image_position = self.left_position
                self.animation()
        if self.MOVE_RIGHT:
            if self.rect.right <= 900:
                self.rect.move_ip(self.speed, 0)
                self.image_position = self.right_position
                self.animation()
        if self.MOVE_UP:
            if self.rect.top >= 0:
                self.rect.move_ip(0, -self.speed)
                self.image_position = self.up_position
                self.animation()
        if self.MOVE_DOWN:
            if self.rect.bottom <= 650:
                self.rect.move_ip(0, self.speed)
                self.image_position = self.down_position
                self.animation()
    def shoot(self):
        if self.number_of_bullets > 0:
            if surv.image_position == self.left_position:
                direction = 3
            elif surv.image_position == self.right_position:
                direction = 1
            elif surv.image_position == self.up_position:
                direction = 2
            elif surv.image_position == self.down_position:
                direction = 4
            projectile = Projectile('images/projectile.png', direction)
            projectile.image = rotate_projectile(projectile.image, projectile)
            self.shoot_index += 1
            if int(self.shoot_index) >= len(self.images_shoot):
                self.shoot_index = 0
            self.image = self.images_shoot[int(self.shoot_index)]
            self.image = rotate_image(self.image_position, self.image, self)
            self.number_of_bullets -= 1
            projectiles.add(projectile)
    def draw(self, screen):
        screen.blit(self.image, self.rect)

class Home:
    def __init__(self, image, health):
        self.image = pygame.image.load(image)
        self.image = pygame.transform.scale(self.image, (200, 170))
        self.health = health
        self.rect = self.image.get_rect(center=(900 // 2, 650 // 2))

    def draw(self, screen):
        screen.blit(self.image, self.rect)

def get_move_zombie_sprites():
    images_move = []
    for i in range(1, 17):
        sprite_move = pygame.image.load(f'images/skeleton-move_{i}.png')
        sprite_move = pygame.transform.scale(sprite_move, (125, 125))
        images_move.append(sprite_move)
    return images_move
def get_attack_zombie_sprites():
    images_attack = []
    for i in range(9):
        sprite_attack = pygame.image.load(f'images/skeleton-attack_{i}.png')
        sprite_attack = pygame.transform.scale(sprite_attack, (125, 125))
        images_attack.append(sprite_attack)
    return images_attack

class Zombie(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.images_move = get_move_zombie_sprites()
        self.images_attack = get_attack_zombie_sprites()
        self.move_index = 0
        self.attack_index = 0
        self.image = self.images_move[self.move_index]
        self.rect = self.image.get_rect(center=(0, H // 2))
        self.speed = 2
        self.direction = random.randint(1, 4)
        self.health = 100
        self.damage = 10
        self.set_position()
    
    def set_position(self):
        if self.direction == 1:
            self.rect.center = (0, H // 2)
        if self.direction == 2:
            self.rect.center = (W, H // 2)
        if self.direction == 3:
            self.rect.center = (W // 2, H)
        if self.direction == 4:
            self.rect.center = (W // 2, 0)

    def update(self):
        if self.rect.colliderect(home.rect):
            self.attack_index += 0.25
            if int(self.attack_index) >= len(self.images_attack):
                self.attack_index = 0
                home.health -= self.damage
                if home.health < 0:
                    home.health = 0
                zombs.remove(self)
            self.image = self.images_attack[int(self.attack_index)]
            self.image = rotate_zombie(self.image, self.direction)
        else:
            self.move_index += 0.25
            if int(self.move_index) >= len(self.images_move):
                self.move_index = 0
            self.image = self.images_move[int(self.move_index)]
            self.image = rotate_zombie(self.image, self.direction)
            if not self.rect.colliderect(surv.rect):
                move_zombie_rect(self.rect, self.direction, self.speed)
        
class Projectile(pygame.sprite.Sprite):
    def __init__(self, image, direction):
        pygame.sprite.Sprite.__init__(self)
        self.speed = 10
        self.damage = 50
        self.direction = direction
        self.image = pygame.image.load(image)
        self.rect = self.image.get_rect()
        if self.direction == 1:
            self.rect.center = (surv.rect.center[0] + 60, surv.rect.center[1] + 25)
        if self.direction == 2:
            self.rect.center = (surv.rect.center[0], surv.rect.center[1] - 50)
        if self.direction == 3:
            self.rect.center = (surv.rect.center[0] - 70, surv.rect.center[1] - 25)
        if self.direction == 4:
            self.rect.center = (surv.rect.center[0] - 48, surv.rect.center[1] + 85)
        self.left_position = pygame.transform.rotate(self.image, 180)
        self.right_position = pygame.transform.rotate(self.image, 0)
        self.up_position = pygame.transform.rotate(self.image, 90)
        self.down_position = pygame.transform.rotate(self.image, -90)

    def update(self):
        if self.direction == 1:
            self.rect.move_ip(self.speed, 0)
            self.image = self.right_position
        if self.direction == 2:
            self.rect.move_ip(0, -self.speed)
            self.image = self.up_position
        if self.direction == 3:
            self.rect.move_ip(-self.speed, 0)
            self.image = self.left_position
        if self.direction == 4:
            self.rect.move_ip(0, self.speed)
            self.image = self.down_position
    def check_colliderect_with_medkit(self, medkits, projectiles):
        for medkit in medkits:
            if self.rect.colliderect(medkit.rect):
                projectiles.remove(self)
                medkits.remove(medkit)
    def check_colliderect_with_box(self, boxes, projectiles):
        for box in boxes:
            if self.rect.colliderect(box.rect):
                projectiles.remove(self)
                boxes.remove(box)
    def check_colliderect_with_zombie(self, zombs, projectiles):
        for zombie in zombs:
            if self.rect.colliderect(zombie.rect):
                zombie.health -= self.damage
                projectiles.remove(self)
                if zombie.health <= 0: 
                    zombs.remove(zombie)
    def draw(self, screen):
        screen.blit(self.image, self.rect)

class Medkit(pygame.sprite.Sprite):
    def __init__(self, image, direction):
        pygame.sprite.Sprite.__init__(self)
        self.direction = direction
        self.hp = 100 - home.health
        self.image = pygame.image.load(image)
        self.rect = self.image.get_rect()
        if self.direction == 1:
            self.rect = self.image.get_rect(center=(325, 219))
        if self.direction == 2:
            self.rect = self.image.get_rect(center=(575, 431))

    def surv_colliderect_with_medkit(self, sound, group):
        if surv.rect.colliderect(self.rect):
            sound.play()
            home.health += self.hp
            group.remove(self)

class BoxAmmo(pygame.sprite.Sprite):
    def __init__(self, image, direction):
        pygame.sprite.Sprite.__init__(self)
        self.direction = direction
        self.bullet = 100
        self.image = pygame.image.load(image)
        self.image = pygame.transform.scale(self.image, (65, 65))
        if self.direction == 1:
            self.rect = self.image.get_rect(center=(575, 219))
        elif self.direction == 2:
            self.rect = self.image.get_rect(center=(325, 431))

    def surv_colliderect_with_box(self, sound, group):
        if surv.rect.colliderect(self.rect):
            sound.play()
            surv.number_of_bullets += self.bullet
            group.remove(self)
        
surv = Player(100, 6)
home = Home("images/home.png", 100)  

def rotate_zombie(image, direction):
    if direction == 1:
        return pygame.transform.rotate(image, 0)
    elif direction == 2:
        return pygame.transform.rotate(image, 180)
    elif direction == 3:
        return pygame.transform.rotate(image, 90)
    else:
        return pygame.transform.rotate(image, -90)
    
def move_zombie_rect(rect, direction, speed):
    if direction == 1:
        rect.move_ip(speed, 0)
    elif direction == 2:
        rect.move_ip(-speed, 0)
    elif direction == 3:
        rect.move_ip(0, -speed)
    else:
        rect.move_ip(0, speed)
def rotate_image(image_position, image, object):
    if image_position == object.left_position:
        return pygame.transform.rotate(image, 180)
    if image_position == object.right_position:
        return pygame.transform.rotate(image, 0)
    if image_position == object.up_position:
        return pygame.transform.rotate(image, 90)
    if image_position == object.down_position:
        return pygame.transform.rotate(image, -90)
def rotate_projectile(image, object):
    if image == object.left_position:
        return pygame.transform.rotate(image, 180)
    if image == object.right_position:
        return pygame.transform.rotate(image, 0)
    if image == object.up_position:
        return pygame.transform.rotate(image, 90)
    if image == object.down_position:
        return pygame.transform.rotate(image, -90)

W = 900
H = 650
screen = pygame.display.set_mode((W, H))
gameWorking = True
sand = pygame.image.load("images/sand.jpg")
projectileImage = pygame.image.load("images/projectile.png")
heart = pygame.image.load("images/heart.png")
heart = pygame.transform.scale(heart, (34, 30))

text = pygame.font.Font('fonts/Old-Soviet.otf', 26)
text_game_over = pygame.font.Font('fonts/Nord-Star-Deco.ttf', 96)
background_music_volume = 0
zombie_music_volume = 0.1
music_fone = pygame.mixer.music.load('sounds/ActionMusic.mp3')
music_fone = pygame.mixer.music.set_volume(background_music_volume)
pygame.mixer.music.play(loops=-1, start= 0.0, fade_ms= 0)
catchSound = pygame.mixer.Sound('sounds/Catch.wav')
fireSound = pygame.mixer.Sound('sounds/fire.wav')
zombieSound = pygame.mixer.Sound('sounds/zombie.wav')
zombieSound.set_volume(zombie_music_volume)

def check_projectiles_colliderect(projectiles):
    for projectile in projectiles:
        projectile.check_colliderect_with_medkit(medkits, projectiles)
        projectile.check_colliderect_with_box(boxes, projectiles)
        projectile.check_colliderect_with_zombie(zombs, projectiles)

def draw_health_home(screen, image):
    screen.blit(image, (0, 0))
    health_home = text.render(f'{home.health}', 1, white)
    screen.blit(health_home, (34, 0))
def draw_bullet(screen, image):
    screen.blit(image, (870, 620))
    surv_of_billets = text.render(f'{surv.number_of_bullets}', 1, white)
    screen.blit(surv_of_billets, (835, 620))
def draw_game_over(screen):
    gameOver = text_game_over.render('Game Over', 1, white)
    gameOverRect = gameOver.get_rect(center=(900 // 2, 650 // 2))
    screen.blit(gameOver, gameOverRect)

play_ = MenuButton( 
                    font=decrypted_120, text="PLAY", 
                    color_text=(0, 0, 0,),
                    background_color=(255, 255, 255), 
                    pos_x=W // 2, 
                    pos_y=H // 4,
                    size=(400, 75)
                    )
easy = MenuButton( 
                    font=decrypted_120, text="EASY", 
                    color_text=(0, 0, 0,),
                    background_color=(255, 255, 255), 
                    pos_x=W // 2, 
                    pos_y=H // 4,
                    size=(400, 75)
                    )
overage = MenuButton( 
                    font=decrypted_120, text="OVERAGE", 
                    color_text=(0, 0, 0,),
                    background_color=(255, 255, 255), 
                    pos_x=W // 2, 
                    pos_y=H // 4 + H // 4,
                    size=(400, 75)
                    )
hard = MenuButton( 
                    font=decrypted_120, text="HARD", 
                    color_text=(0, 0, 0,),
                    background_color=(255, 255, 255), 
                    pos_x=W // 2, 
                    pos_y=H // 4 * 3,
                    size=(400, 75)
                    )
exit = MenuButton( 
                    font=decrypted_120, text="EXIT", 
                    color_text=(0, 0, 0),
                    background_color=(255, 255, 255), 
                    pos_x=W // 2, 
                    pos_y=H // 4 * 3,
                    size=(400, 75)
                    )
settings = MenuButton(
                        font=decrypted_120, text="SETTINGS",
                        color_text=(0, 0, 0),
                        background_color=(255, 255, 255),
                        pos_x=W // 2,
                        pos_y=H // 4 * 2,
                        size=(400, 75))
exit_to_main_menu = MenuButton( 
                    font=decrypted_120, text="EXIT TO MAIN MENU", 
                    color_text=(0, 0, 0),
                    background_color=(255, 255, 255), 
                    pos_x=W // 2, 
                    pos_y=H // 3 * 2,
                    size=(675, 75)
                    )

game_state = GameState()

while gameWorking:
    game_state.state_manager()
    clock.tick(FPS)