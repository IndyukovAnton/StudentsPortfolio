import pygame
import font
import color
import settings

class Home:
    def __init__(self, image, health):
        self.image = pygame.image.load(image)
        self.image = pygame.transform.scale(self.image, (200, 170))
        self.health = health
        self.rect = self.image.get_rect(center=(900 // 2, 650 // 2))

    def draw(self, screen):
        screen.blit(self.image, self.rect)
    
home = Home("images/background/home.png", 100) 

heart = pygame.image.load("images/heart.png")
heart = pygame.transform.scale(heart, (34, 30))

def draw_health_home(screen, image):
    settings.screen.blit(image, (0, 0))
    health_home = font.OLD_SOVIET_26.render(f'{home.health}', 1, color.WHITE)
    settings.screen.blit(health_home, (34, 0))

