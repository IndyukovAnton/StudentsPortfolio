import pygame

SCREEN_WIDTH = 900
SCREEN_HEIGHT = 650
FPS = 60

# частота спавна зомби
zombie_spawn_rate = 3
# частота спавна аптечки
medkit_spawn_rate = 10
# частота спавна пуль
ammo_spawn_rate = 10


screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))