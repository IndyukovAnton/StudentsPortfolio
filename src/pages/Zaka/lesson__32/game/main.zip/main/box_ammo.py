import pygame
import player

class BoxAmmo(pygame.sprite.Sprite):
    def __init__(self, image, direction):
        pygame.sprite.Sprite.__init__(self)
        self.direction = direction
        self.bullet = 100
        self.image = pygame.image.load(image)
        self.image = pygame.transform.scale(self.image, (65, 65))
        if self.direction == 1:
            self.rect = self.image.get_rect(center=(575, 219))
        elif self.direction == 2:
            self.rect = self.image.get_rect(center=(325, 431))

    def surv_colliderect_with_box(self, sound, group):
        if player.surv.rect.colliderect(self.rect):
            sound.play()
            player.surv.number_of_bullets += self.bullet
            group.remove(self)
            if player.surv.number_of_bullets > 150:
                player.surv.number_of_bullets = 150