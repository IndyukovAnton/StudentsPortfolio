import pygame

catchSound = pygame.mixer.Sound('sounds/Catch.wav')
fireSound = pygame.mixer.Sound('sounds/fire.wav')
zombieSound = pygame.mixer.Sound('sounds/zombie.wav')

background_music_volume = 0
music_fone = pygame.mixer.music.load('sounds/ActionMusic.mp3')
music_fone = pygame.mixer.music.set_volume(background_music_volume)