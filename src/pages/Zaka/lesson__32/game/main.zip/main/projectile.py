import pygame
import player
import box_ammo


def rotate_projectile(image, object):
    if image == object.left_position:
        return pygame.transform.rotate(image, 180)
    if image == object.right_position:
        return pygame.transform.rotate(image, 0)
    if image == object.up_position:
        return pygame.transform.rotate(image, 90)
    if image == object.down_position:
        return pygame.transform.rotate(image, -90)


class Projectile(pygame.sprite.Sprite):
    def __init__(self, image, direction):
        pygame.sprite.Sprite.__init__(self)
        self.speed = 10
        self.damage = 50
        self.direction = direction
        self.image = pygame.image.load(image)
        self.rect = self.image.get_rect()
        if self.direction == 1:
            self.rect.center = (player.surv.rect.center[0] + 60, player.surv.rect.center[1] + 25)
        if self.direction == 2:
            self.rect.center = (player.surv.rect.center[0], player.surv.rect.center[1] - 50)
        if self.direction == 3:
            self.rect.center = (player.surv.rect.center[0] - 70, player.surv.rect.center[1] - 25)
        if self.direction == 4:
            self.rect.center = (player.surv.rect.center[0] - 48, player.surv.rect.center[1] + 85)
        self.left_position = pygame.transform.rotate(self.image, 180)
        self.right_position = pygame.transform.rotate(self.image, 0)
        self.up_position = pygame.transform.rotate(self.image, 90)
        self.down_position = pygame.transform.rotate(self.image, -90)

    def update(self, medkits, boxes, zombies, projectile_group):
        if self.direction == 1:
            self.rect.move_ip(self.speed, 0)
            self.image = self.right_position
        if self.direction == 2:
            self.rect.move_ip(0, -self.speed)
            self.image = self.up_position
        if self.direction == 3:
            self.rect.move_ip(-self.speed, 0)
            self.image = self.left_position
        if self.direction == 4:
            self.rect.move_ip(0, self.speed)
            self.image = self.down_position
        self.check_colliderect_with_box(boxes, projectile_group)
        self.check_colliderect_with_medkit(medkits, projectile_group)
        self.check_colliderect_with_zombie(zombies, projectile_group)

    def check_colliderect_with_medkit(self, medkits, projectiles):
        for medkit in medkits:
            if self.rect.colliderect(medkit.rect):
                projectiles.remove(self)
                medkits.remove(medkit)

    def check_colliderect_with_box(self, boxes, projectiles):
        for box in boxes:
            if self.rect.colliderect(box.rect):
                projectiles.remove(self)
                box_ammo.boxes.remove(box)

    def check_colliderect_with_zombie(self, zombs, projectiles):
        for zombie in zombs:
            if self.rect.colliderect(zombie.rect):
                zombie.health -= self.damage
                projectiles.remove(self)
                if zombie.health <= 0: 
                    zombs.remove(zombie)

projectileImage = pygame.image.load("images/bullet/projectile.png")