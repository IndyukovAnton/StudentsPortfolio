from screens.menu import main_menu
from screens.choose_coplexity import choose_complexity
from screens.settings_screen import settings_screen
from screens.exit_to_main_menu import exit_to_main_menu
from screens.levels.first_level import game


class GameManager:
    
    def __init__(self):
        self.state = 'main_menu'
        self.game_working = True

    def state_manger(self):
        if self.state == 'main_menu':
            main_menu(self)
        elif self.state == 'choose_complexity':
            choose_complexity(self)
        elif self.state == 'settings_screen':
            settings_screen(self)
        elif self.state == "exit_to_main_menu":
            exit_to_main_menu(self)
        elif self.state == "game":
            game(self)
